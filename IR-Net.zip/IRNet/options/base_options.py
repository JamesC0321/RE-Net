import argparse
import os
from util import util
import torch


class BaseOptions():
	def __init__(self):
		self.parser = argparse.ArgumentParser()
		self.initialized = False
	
	def initialize(self):
		self.parser.add_argument('--dataroot', default='./image')
		self.parser.add_argument('--batchSize', type=int, default=4)
		self.parser.add_argument('--loadSize', type=int, default=256)
		self.parser.add_argument('--fineSize', type=int, default=256)
		self.parser.add_argument('--patchSize', type=int, default=64)
		self.parser.add_argument('--input_nc', type=int, default=3)
		self.parser.add_argument('--output_nc', type=int, default=3)
		self.parser.add_argument('--ngf', type=int, default=64)
		self.parser.add_argument('--ndf', type=int, default=64)
		self.parser.add_argument('--which_model_netD', type=str, default='basic')
		self.parser.add_argument('--which_model_netG', type=str, default='unet_256')
		self.parser.add_argument('--n_layers_D', type=int, default=3)
		self.parser.add_argument('--n_layers_patchD', type=int, default=3)
		self.parser.add_argument('--gpu_ids', type=str, default='0')
		self.parser.add_argument('--name', type=str, default='experiment_name')
		self.parser.add_argument('--dataset_mode', type=str, default='unaligned')
		self.parser.add_argument('--model', type=str, default='cycle_gan')
		self.parser.add_argument('--which_direction', type=str, default='AtoB')
		self.parser.add_argument('--nThreads', default=4, type=int)
		self.parser.add_argument('--checkpoints_dir', type=str, default='./checkpoints')
		self.parser.add_argument('--norm', type=str, default='instance')
		self.parser.add_argument('--serial_batches', action='store_true')
		self.parser.add_argument('--display_winsize', type=int, default=256)
		self.parser.add_argument('--display_id', type=int, default=1)
		self.parser.add_argument('--display_port', type=int, default=8098)
		self.parser.add_argument('--display_single_pane_ncols', type=int, default=0)
		self.parser.add_argument('--identity', type=float, default=0.0)
		self.parser.add_argument('--no_dropout', action='store_true')
		self.parser.add_argument('--lambda_A', type=float, default=10.0)
		self.parser.add_argument('--lambda_B', type=float, default=10.0)
		self.parser.add_argument('--max_dataset_size', type=int, default=float("inf"))
		self.parser.add_argument('--resize_or_crop', type=str, default='crop')
		self.parser.add_argument('--no_flip', default=False)
		self.parser.add_argument('--skip', type=float, default=0.8)
		self.parser.add_argument('--use_mse', action='store_true')
		self.parser.add_argument('--l1', type=float, default=10.0)
		self.parser.add_argument('--use_norm', type=float, default=10)
		self.parser.add_argument('--use_wgan', type=float, default=0)
		self.parser.add_argument('--use_ragan', action='store_true')
		self.parser.add_argument('--vgg', type=float, default=0)
		self.parser.add_argument('--vgg_mean', action='store_true')
		self.parser.add_argument('--vgg_choose', type=str, default='relu5_3')
		self.parser.add_argument('--no_vgg_instance', action='store_true')
		self.parser.add_argument('--vgg_maxpooling', action='store_true')
		self.parser.add_argument('--IN_vgg', action='store_true')
		self.parser.add_argument('--fcn', type=float, default=0)
		self.parser.add_argument('--use_avgpool', type=float, default=0)
		self.parser.add_argument('--instance_norm', type=float, default=0)
		self.parser.add_argument('--syn_norm', action='store_true')
		self.parser.add_argument('--tanh', action='store_true')
		self.parser.add_argument('--linear', action='store_true')
		self.parser.add_argument('--new_lr', action='store_true')
		self.parser.add_argument('--multiply', action='store_true')
		self.parser.add_argument('--noise', type=float, default=0)
		self.parser.add_argument('--input_linear', action='store_true')
		self.parser.add_argument('--linear_add', action='store_true')
		self.parser.add_argument('--latent_threshold', action='store_true')
		self.parser.add_argument('--latent_norm', action='store_true')
		self.parser.add_argument('--patchD', action='store_true')
		self.parser.add_argument('--patchD_3', type=int, default=0)
		self.parser.add_argument('--D_P_times2', action='store_true')
		self.parser.add_argument('--patch_vgg', action='store_true')
		self.parser.add_argument('--hybrid_loss', action='store_true')
		self.parser.add_argument('--self_attention', action='store_true')
		self.parser.add_argument('--times_residual', action='store_true')
		self.parser.add_argument('--low_times', type=int, default=200)
		self.parser.add_argument('--high_times', type=int, default=400)
		self.parser.add_argument('--norm_attention', action='store_true')
		self.parser.add_argument('--vary', type=int, default=1)
		self.parser.add_argument('--lighten', action='store_true')
		self.initialized = True
	
	def parse(self):
		if not self.initialized:
			self.initialize()
		self.opt = self.parser.parse_args()
		self.opt.isTrain = self.isTrain
		str_ids = self.opt.gpu_ids.split(',')
		self.opt.gpu_ids = []
		for str_id in str_ids:
			id = int(str_id)
			if id >= 0:
				self.opt.gpu_ids.append(id)
		if len(self.opt.gpu_ids) > 0:
			torch.cuda.set_device(self.opt.gpu_ids[0])
		args = vars(self.opt)
		print('------------ Options -------------')
		for k, v in sorted(args.items()):
			print('%s: %s' % (str(k), str(v)))
		print('-------------- End ----------------')
		expr_dir = os.path.join(self.opt.checkpoints_dir, self.opt.name)
		util.mkdirs(expr_dir)
		file_name = os.path.join(expr_dir, 'opt.txt')
		with open(file_name, 'wt') as opt_file:
			opt_file.write('------------ Options -------------\n')
			for k, v in sorted(args.items()):
				opt_file.write('%s: %s\n' % (str(k), str(v)))
			opt_file.write('-------------- End ----------------\n')
		return self.opt
