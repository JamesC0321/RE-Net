from .base_options import BaseOptions


class TrainOptions(BaseOptions):
    def initialize(self):
        BaseOptions.initialize(self)
        self.parser.add_argument('--display_freq', type=int, default=30)
        self.parser.add_argument('--print_freq', type=int, default=100)
        self.parser.add_argument('--save_latest_freq', type=int, default=50000)
        self.parser.add_argument('--save_epoch_freq', type=int, default=50)
        self.parser.add_argument('--continue_train',default=False, action='store_true')
        self.parser.add_argument('--phase', type=str, default='train')
        self.parser.add_argument('--which_epoch', type=str, default='166')
        self.parser.add_argument('--niter', type=int, default=100)
        self.parser.add_argument('--niter_decay', type=int, default=100)
        self.parser.add_argument('--beta1', type=float, default=0.5)
        self.parser.add_argument('--lr', type=float, default=0.0001)
        self.parser.add_argument('--no_lsgan', action='store_true')
        self.parser.add_argument('--pool_size', type=int, default=16)
        self.parser.add_argument('--no_html', action='store_true')
        self.parser.add_argument('--config', type=str, default='./config.yaml')
        self.isTrain = True
