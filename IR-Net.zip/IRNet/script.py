import os
import argparse
import time
from datetime import datetime

parser = argparse.ArgumentParser()
parser.add_argument("--port", type=str, default="8097")
parser.add_argument("--train", action='store_true')
parser.add_argument("--predict", action='store_true')
opt = parser.parse_args()


if opt.train:
	os.system(f"python train.py \
		--dataroot ./image  \
		--no_dropout \
		--name your_name \
		--model single \
		--dataset_mode unaligned \
		--which_model_netG net \
		--which_model_netD no_norm_4 \
		--patchD \
		--patch_vgg \
		--patchD_3 5 \
		--n_layers_D 5 \
		--n_layers_patchD 4 \
		--fineSize 256 \
		--patchSize 32 \
		--skip 1 \
		--batchSize 16 \
		--self_attention \
		--use_norm 1 \
		--use_wgan 0 \
		--use_ragan \
		--use_ragan \
		--hybrid_loss \
		--times_residual \
		--instance_norm 0 \
		--vgg 1 \
		--vgg_choose relu5_1 \
		--which_epoch 200 \
		--gpu_ids 0 \
		--display_port=" + opt.port)

elif opt.predict:
	for i in range(1):
		os.system(f'python predict.py  \
				--dataroot  ./image \
				--name your_name  \
				--model single \
				--which_direction AtoB \
				--no_dropout \
				--dataset_mode unaligned \
				--which_model_netG net \
				--skip 1 \
				--use_norm 1 \
				--use_wgan 0 \
				--self_attention \
				--times_residual \
				--gpu_ids 0 \
				--instance_norm 0 --resize_or_crop=\'no\'\
				--which_epoch 200')


