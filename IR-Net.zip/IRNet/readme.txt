1.prepare the environmet:
    python==3.6
    pytorch==1.8
    visdom==0.1.2
    pynvml==11.5.0
2.Training:
    python script.py --train
3.Testing:
    python script.py --predict