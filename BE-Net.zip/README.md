# BE-Net
Please add a dataset before running train.py and  modify the corresponding path

The submission mainly contains:
1. architecture (called BE-Net) in networks/BE.py
2. Training Script (train.py)
3. Evaluation script (eval.py)

