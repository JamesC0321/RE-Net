import torch
import torch.nn as nn
from torch.autograd import Variable as V

import cv2
import numpy as np


class MyFrame():
    def __init__(self, net, loss, lr=2e-4, evalmode=False):
        self.net = net().cuda()
        self.net = torch.nn.DataParallel(self.net, device_ids=range(torch.cuda.device_count()))
        self.optimizer = torch.optim.Adam(params=self.net.parameters(), lr=lr,weight_decay=1e-6)
        # self.optimizer = torch.optim.SGD(params=self.net.parameters(), lr=lr)
        self.loss = loss()
        self.old_lr = lr
        self.pool1=nn.AvgPool2d(2,2)
        self.pool2=nn.AvgPool2d(4,4)
        if evalmode:
            for i in self.net.modules():
                if isinstance(i, nn.BatchNorm2d):
                    i.eval()
        
    def set_input(self, img_batch, mask_batch=None, img_id=None):
        self.img = img_batch
        self.mask = mask_batch
        self.img_id = img_id
        
    def test_one_img(self, img):
        pred = self.net.forward(img)
        
        pred[pred>0.5] = 1
        pred[pred<=0.5] = 0

        mask = pred.squeeze().cpu().data.numpy()
        return mask
    
    def test_batch(self):
        self.forward(volatile=True)
        mask =  self.net.forward(self.img).cpu().data.numpy().squeeze(1)
        mask[mask>0.5] = 1
        mask[mask<=0.5] = 0
        
        return mask, self.img_id
    
    def test_one_img_from_path(self, path):
        img = cv2.imread(path)
        img = np.array(img, np.float32)/255.0 * 3.2 - 1.6
        img = V(torch.Tensor(img).cuda())
        
        mask = self.net.forward(img).squeeze().cpu().data.numpy()#.squeeze(1)
        mask[mask>0.5] = 1
        mask[mask<=0.5] = 0
        
        return mask
        
    def forward(self, volatile=False):
        self.img = V(self.img.cuda(), volatile=volatile)
        if self.mask is not None:
            self.mask = V(self.mask.cuda(), volatile=volatile)
        

    def optimize_pnet(self):
        self.forward()
        self.optimizer.zero_grad()
        pred = self.net.forward(self.img)

        pred1 = torch.reshape(pred , (1,2,-1))
        mask1 = torch.reshape(self.mask, (1,2, -1))
        loss1 = self.loss(mask1, pred1)

        mask2=self.pool1(self.mask)
        pred2=self.pool1(pred)
        pred2 = torch.reshape(pred2 , (1,2,-1))
        mask2 = torch.reshape(mask2, (1,2, -1))
        loss2 = self.loss(mask2, pred2)

        mask3=self.pool2(self.mask)
        pred3=self.pool2(pred)
        pred3 = torch.reshape(pred3 , (1,2,-1))
        mask3 = torch.reshape(mask3, (1,2, -1))
        loss3 = self.loss(mask3, pred3)

        loss = (loss3+loss1+loss2)/3
        loss.backward()
        self.optimizer.step()
        return loss.data, pred

    def val_pnet(self):
        pred = self.net.forward(self.img)

        pred1 = torch.reshape(pred, (1, 2, -1))
        mask1 = torch.reshape(self.mask, (1, 2, -1))
        loss1 = self.loss(mask1, pred1)

        mask2 = self.pool1(self.mask)
        pred2 = self.pool1(pred)
        pred2 = torch.reshape(pred2, (1, 2, -1))
        mask2 = torch.reshape(mask2, (1, 2, -1))
        loss2 = self.loss(mask2, pred2)

        mask3 = self.pool2(self.mask)
        pred3 = self.pool2(pred)
        pred3 = torch.reshape(pred3, (1, 2, -1))
        mask3 = torch.reshape(mask3, (1, 2, -1))
        loss3 = self.loss(mask3, pred3)

        loss = (loss3 + loss1 + loss2) / 3
        return loss.data, pred

    def optimize_new_unet(self):
        self.forward()
        self.optimizer.zero_grad()

        pred = self.net.forward(self.img)
        pred = torch.reshape(pred , (1,2,-1))
        mask = torch.reshape(self.mask, (1,2, -1))

        #tempL = torch.zeros(2,65536)
        #tempL[0,:] = mask
        #tempL[1, :] = 1-mask

        loss = self.loss(mask, pred)
        loss.backward()
        self.optimizer.step()
        return loss.data, pred

    def val_new_unet(self):
        pred = self.net.forward(self.img)
        pred = torch.reshape(pred, (1, 2, -1))
        mask = torch.reshape(self.mask, (1,2, -1))
        loss = self.loss(mask, pred)

        return loss.data, pred


    def optimize(self):
        self.forward()
        self.optimizer.zero_grad()
        pred = self.net.forward(self.img)

        loss = self.loss(self.mask, pred)
        loss.backward()
        self.optimizer.step()
        return loss.data, pred


    def val(self):
        pred = self.net.forward(self.img)
        loss = self.loss(self.mask, pred)

        return loss.data, pred
    def save(self, path):
        torch.save(self.net.state_dict(), path)
        
    def load(self, path):
        self.net.load_state_dict(torch.load(path))
    
    def update_lr(self, new_lr, mylog, factor=False):
        if factor:
            new_lr = self.old_lr / new_lr
        for param_group in self.optimizer.param_groups:
            param_group['lr'] = new_lr

        print (mylog, 'update learning rate: %f -> %f' % (self.old_lr, new_lr))
        print ('update learning rate: %f -> %f' % (self.old_lr, new_lr))
        self.old_lr = new_lr
