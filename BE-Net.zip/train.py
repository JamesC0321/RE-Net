from __future__ import division
from __future__ import print_function
from __future__ import absolute_import

import os
from tqdm import tqdm
import torch.utils.data as data
from networks.BE import BENet
from framework import MyFrame
from loss import *
from data1 import BENet_ImageFolder
import Constants

# Please specify the ID of graphics cards that you want to use
os.environ['CUDA_VISIBLE_DEVICES'] = "0"


def set_rand_seed(seed=1):
    print("Random Seed: ", seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    # torch.backends.cudnn.enabled = False
    torch.backends.cudnn.benchmark = False
    torch.backends.cudnn.deterministic = True  # 保证每次返回得的卷积算法是确定的


set_rand_seed()

def Net_Train():
    NAME = 'BE_1'
    solver = MyFrame(BENet, dice_bce_loss, 1e-4)

    batchsize = torch.cuda.device_count() * Constants.BATCHSIZE_PER_CARD
    scheduler = torch.optim.lr_scheduler.StepLR(solver.optimizer,50, 1)

    trian_dataset = BENet_ImageFolder(root_path=Constants.ROOT, datasets='fetal_all',
                                model='train')  # 'DRIVE', 'CHASE_DB1','START'
    trian_data_loader = torch.utils.data.DataLoader(trian_dataset,
                                                    batch_size=batchsize,
                                                    shuffle=True,
                                                    num_workers=0)
    val_dataset = BENet_ImageFolder(root_path=Constants.ROOT, datasets='fetal_all', model='val')
    val_data_loader = torch.utils.data.DataLoader(val_dataset, batch_size=batchsize)

    mylog = open('logs/' + NAME + '.log', 'w')
    # tic = time()

    no_optim = 0
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    total_epoch = Constants.TOTAL_EPOCH
    val_epoch_best_loss = Constants.INITAL_EPOCH_LOSS
    up = 0
    for epoch in range(1, total_epoch + 1):
        data_loader_iter = iter(trian_data_loader)
        train_epoch_loss = 0
        index = 0
        # scheduler.step()
        for img, mask in tqdm(data_loader_iter):
            img = img.to(device)
            mask = mask.to(device)
            solver.set_input(img, mask)
            train_loss, pred = solver.optimize()
            train_epoch_loss += train_loss
            index = index + 1
        train_epoch_loss = train_epoch_loss / len(data_loader_iter)

        # val
        y_loss = 0.0
        with torch.no_grad():
            for i, (imgs, masks) in enumerate(val_data_loader):
                imgs = imgs.to(device)
                masks = masks.to(device)
                solver.set_input(imgs, masks)
                loss, val_pred = solver.val()
                y_loss = y_loss + loss
            val_loss = y_loss / len(val_data_loader)

        # scheduler.step()
        print('val_loss', val_loss)
        mylog.write('epoch: ' + str(epoch) + ' ' + ' train_loss: ' + str(train_epoch_loss.cpu().numpy()) + '\n')
        print('epoch:', epoch, 'train_loss:', train_epoch_loss.cpu().numpy(), 'lr: ' + format(scheduler.get_lr()[0]))

        if val_loss >= val_epoch_best_loss:
            no_optim += 1
            print(no_optim)

        if val_loss < val_epoch_best_loss:
            no_optim = 0
            val_epoch_best_loss = val_loss
            print(no_optim)
            print('Sucessful save', val_loss)
            solver.save('./weights/' + NAME + '.th')

        if no_optim > Constants.NUM_EARLY_STOP:
            print(mylog, 'early stop at %d epoch' % epoch)
            print('early stop at %d epoch' % epoch)
            break

        mylog.flush()

    print(mylog, 'Finish!')
    print('Finish!')
    mylog.close()


if __name__ == '__main__':
    Net_Train()
