from scipy.spatial.distance import directed_hausdorff
import cv2
import os
import numpy as np
import torch
import warnings
warnings.filterwarnings('ignore')
from time import time
from networks.BE import BENet

os.environ['CUDA_VISIBLE_DEVICES'] = '0'
from PIL import Image



def set_rand_seed(seed=1):
    print("Random Seed: ", seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    # torch.backends.cudnn.enabled = False
    torch.backends.cudnn.benchmark = False
    torch.backends.cudnn.deterministic = True  # 保证每次返回得的卷积算法是确定的


set_rand_seed()



def accuracy(pred_mask, label):
    '''
    acc=(TP+TN)/(TP+FN+TN+FP)
    '''
    pred_mask = pred_mask.astype(np.uint8)
    TP, FN, TN, FP = [0, 0, 0, 0]
    for i in range(label.shape[0]):
        for j in range(label.shape[1]):
            if label[i][j] == 1:
                if pred_mask[i][j] == 1:
                    TP += 1
                elif pred_mask[i][j] == 0:
                    FN += 1
            elif label[i][j] == 0:
                if pred_mask[i][j] == 1:
                    FP += 1
                elif pred_mask[i][j] == 0:#ACCURACY
                    TN += 1
    acc = (TP + TN) / (TP + FN + TN + FP)
    sen = TP / (TP + FN)#sensitivity
    dice = 2*TP/(FN + 2*TP + FP)
    precision = TP / (TP + FP)
    return acc, dice ,sen, precision


def find_max(img):
    img=img.astype(np.uint8)
    ret, binary = cv2.threshold(img, 250, 255, cv2.THRESH_BINARY)
    contours, hierarchy = cv2.findContours(binary, cv2.RETR_CCOMP, cv2.CHAIN_APPROX_SIMPLE)

    area = []

    for j in range(len(contours)):
        area.append(cv2.contourArea(contours[j]))

    max_idx = np.argmax(area)


    for k in range(len(contours)):
        if k != max_idx:
            print(k, 1)
            cv2.fillPoly(img, [contours[k]], (198, 215, 20))

    img[img < 255] = 0
    img[img > 0 ] = 1
    return np.array(img, np.float32)


def main():

    imgsource = './dataset/rand_data/ye/rand2/img'
    labelsource = './dataset/rand_data/ye/rand2/label'
    weight_path = ('./rand_weight/BE_1.th')
    imgname = os.listdir(imgsource)
    net = BENet().cuda()
    net = torch.nn.DataParallel(net, device_ids=range(torch.cuda.device_count()))
    model = torch.load(weight_path)
    net.load_state_dict(model)

    num = 1
    total_acc = []
    total_precision=[]
    total_dice = []
    total_sen = []
    total_hausdorff = []
    total_tic = []
# os.mkdir(target)
    #net.eval()
    for i in (imgname):

        labelfilepath = os.path.join(labelsource, i)
        imgfilepath = os.path.join(imgsource, i)
        img = cv2.imread(imgfilepath)

        label = np.array(Image.open(labelfilepath),np.float32)
        label[label >0] = 1

        img = img / 255.0
        img = np.array(img, np.float32).transpose(2, 0, 1)
        img = np.expand_dims(img, axis=0)
        img = torch.Tensor(img).cuda()

        tic0 = time()
        pred = net.forward(img).squeeze().cpu().data.numpy()

        tic1 = time()
        tic=tic1 - tic0

        pred[pred > 0.5] = 1
        pred[pred <= 0.5] = 0

########MAX#####
        pred = pred * 255.0
        pred = find_max(pred)
########MAX#####

        #pred = cv2.resize(pred, (w, h), interpolation=cv2.INTER_NEAREST)

        hausdorff = directed_hausdorff(pred, label)[0]
        acc, dice, sen ,precision = accuracy(pred, label)
        total_acc.append(acc)
        total_precision.append(precision)
        total_dice.append(dice)
        total_sen.append(sen)
        total_hausdorff.append(hausdorff)
        total_tic.append(tic)
        print('finished:', num , '==>  acc:' , acc , 'precision:', precision ,'dice:' , dice ,'sen:',sen, 'hausdorff:',hausdorff , 'time:',tic)

        num = num + 1

        pred[pred > 0.5] = 255
        pred[pred <= 0.5] = 0


    print('all over')
    print('acc:',np.mean(total_acc),'std:',np.std(total_acc))
    print('precision:', np.mean(total_precision), 'std:', np.std(total_precision))
    print('dice:',np.mean(total_dice),'std:',np.std(total_dice))
    print('sen:', np.mean(total_sen),'std:',np.std(total_sen))
    print('hausdorff:',np.mean(total_hausdorff),'std:',np.std(total_hausdorff))
    print('time:',np.mean(total_tic))



if __name__ == '__main__':
    main()
